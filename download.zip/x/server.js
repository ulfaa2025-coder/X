import express from "express";
import fs from "fs";
import crypto from "crypto";
import path from "path";

const app = express();
const PORT = 3000;

// Simpan token aktif sementara
let activeTokens = {};

// 🛡️ Middleware Anti-curl/wget
app.use((req, res, next) => {
  const badAgents = /(curl|wget|python-requests|libwww|httpclient|okhttp)/i;
  const ua = req.headers["user-agent"] || "";

  if (badAgents.test(ua)) {
    return res.status(403).send("❌ Akses ditolak (bot terdeteksi).");
  }
  next();
});

// 🛡️ Middleware cek Referer (hanya izinkan dari domain tertentu)
app.use((req, res, next) => {
  const allowedDomain = "https://namadomain.com"; // Ganti dengan domain kamu
  const referer = req.headers["referer"] || "";

  if (req.path.startsWith("/download")) {
    if (!referer.startsWith(allowedDomain)) {
      return res.status(403).send("❌ Akses ditolak (Referer tidak valid).");
    }
  }
  next();
});

// Generate token baru (berlaku 1 menit)
app.get("/get-download-link", (req, res) => {
  const token = crypto.randomBytes(16).toString("hex");
  const expire = Date.now() + 60 * 1000; // 1 menit

  activeTokens[token] = expire;

  res.json({
    message: "Gunakan link ini untuk download (berlaku 1 menit)",
    link: `http://localhost:${PORT}/download/${token}`,
  });
});

// Endpoint download dengan token
app.get("/download/:token", (req, res) => {
  const { token } = req.params;
  const now = Date.now();

  if (!activeTokens[token]) {
    return res.status(403).send("❌ Token tidak valid atau sudah dipakai.");
  }

  if (now > activeTokens[token]) {
    delete activeTokens[token];
    return res.status(403).send("⏰ Token expired, minta link baru.");
  }

  // Token valid → hapus agar tidak bisa dipakai lagi
  delete activeTokens[token];

  const filePath = path.join(process.cwd(), "download.zip"); // langsung ke download.zip
  if (!fs.existsSync(filePath)) {
    return res.status(404).send("File tidak ditemukan.");
  }

  res.download(filePath, "download.zip", (err) => {
    if (err) {
      console.error(err);
    }
  });
});

app.listen(PORT, () => {
  console.log(`✅ Server jalan di http://localhost:${PORT}`);
});